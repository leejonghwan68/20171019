from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')
@app.route('/index.html')
def index():
    return render_template('index.html')

@app.route('/ex.html')
def ex():
    return render_template('ex.html')

@app.route('/game.html')
def game():
    return render_template('game.html')

@app.route('/join.html')
def join():
    return render_template('join.html')

@app.route('/login.html')
def login():
    return render_template('login.html')

@app.route('/sign.html')
def sigin():
    return render_template('sign.html')

if __name__ == "__main__":
    app.run(debug=True)